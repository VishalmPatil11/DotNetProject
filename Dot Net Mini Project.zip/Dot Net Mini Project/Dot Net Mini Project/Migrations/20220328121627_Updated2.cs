﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Dot_Net_Mini_Project.Migrations
{
    public partial class Updated2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_iphones_Product_productsCategory",
                table: "iphones");

            migrationBuilder.DropForeignKey(
                name: "FK_Product_users_UserId",
                table: "Product");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Product",
                table: "Product");

            migrationBuilder.RenameTable(
                name: "Product",
                newName: "products");

            migrationBuilder.RenameIndex(
                name: "IX_Product_UserId",
                table: "products",
                newName: "IX_products_UserId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_products",
                table: "products",
                column: "Category");

            migrationBuilder.AddForeignKey(
                name: "FK_iphones_products_productsCategory",
                table: "iphones",
                column: "productsCategory",
                principalTable: "products",
                principalColumn: "Category",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_products_users_UserId",
                table: "products",
                column: "UserId",
                principalTable: "users",
                principalColumn: "UserId",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_iphones_products_productsCategory",
                table: "iphones");

            migrationBuilder.DropForeignKey(
                name: "FK_products_users_UserId",
                table: "products");

            migrationBuilder.DropPrimaryKey(
                name: "PK_products",
                table: "products");

            migrationBuilder.RenameTable(
                name: "products",
                newName: "Product");

            migrationBuilder.RenameIndex(
                name: "IX_products_UserId",
                table: "Product",
                newName: "IX_Product_UserId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Product",
                table: "Product",
                column: "Category");

            migrationBuilder.AddForeignKey(
                name: "FK_iphones_Product_productsCategory",
                table: "iphones",
                column: "productsCategory",
                principalTable: "Product",
                principalColumn: "Category",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Product_users_UserId",
                table: "Product",
                column: "UserId",
                principalTable: "users",
                principalColumn: "UserId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
