﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Dot_Net_Mini_Project.Migrations
{
    public partial class Updated4 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "Category",
                table: "iwatches",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AddColumn<string>(
                name: "productsCategory",
                table: "iwatches",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Category",
                table: "ipads",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AddColumn<string>(
                name: "productsCategory",
                table: "ipads",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Category",
                table: "airpods",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AddColumn<string>(
                name: "productsCategory",
                table: "airpods",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_iwatches_productsCategory",
                table: "iwatches",
                column: "productsCategory");

            migrationBuilder.CreateIndex(
                name: "IX_ipads_productsCategory",
                table: "ipads",
                column: "productsCategory");

            migrationBuilder.CreateIndex(
                name: "IX_airpods_productsCategory",
                table: "airpods",
                column: "productsCategory");

            migrationBuilder.AddForeignKey(
                name: "FK_airpods_products_productsCategory",
                table: "airpods",
                column: "productsCategory",
                principalTable: "products",
                principalColumn: "Category",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_ipads_products_productsCategory",
                table: "ipads",
                column: "productsCategory",
                principalTable: "products",
                principalColumn: "Category",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_iwatches_products_productsCategory",
                table: "iwatches",
                column: "productsCategory",
                principalTable: "products",
                principalColumn: "Category",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_airpods_products_productsCategory",
                table: "airpods");

            migrationBuilder.DropForeignKey(
                name: "FK_ipads_products_productsCategory",
                table: "ipads");

            migrationBuilder.DropForeignKey(
                name: "FK_iwatches_products_productsCategory",
                table: "iwatches");

            migrationBuilder.DropIndex(
                name: "IX_iwatches_productsCategory",
                table: "iwatches");

            migrationBuilder.DropIndex(
                name: "IX_ipads_productsCategory",
                table: "ipads");

            migrationBuilder.DropIndex(
                name: "IX_airpods_productsCategory",
                table: "airpods");

            migrationBuilder.DropColumn(
                name: "productsCategory",
                table: "iwatches");

            migrationBuilder.DropColumn(
                name: "productsCategory",
                table: "ipads");

            migrationBuilder.DropColumn(
                name: "productsCategory",
                table: "airpods");

            migrationBuilder.AlterColumn<string>(
                name: "Category",
                table: "iwatches",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Category",
                table: "ipads",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Category",
                table: "airpods",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);
        }
    }
}
