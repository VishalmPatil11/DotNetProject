﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Dot_Net_Mini_Project.Migrations
{
    public partial class Updated : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
